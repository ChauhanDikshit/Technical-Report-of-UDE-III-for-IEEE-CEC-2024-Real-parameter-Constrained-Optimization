function [aa, bb, numcon] = get_Bounds(func_No)

fname = func_No;
if (fname == 1)
	aa = -100; bb = 100;
	numcon = 1;
elseif (fname == 2)
	aa = -100; bb = 100;
	numcon = 1;
	% DO IT %
elseif (fname == 3)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 4)
	aa = -10; bb = 10;
	numcon = 2;
elseif (fname == 5)
	aa = -10; bb = 10;
	numcon = 2;
elseif (fname == 6)
	aa = -20; bb = 20;
	numcon = 6;
elseif (fname == 7)
	aa = -50; bb = 50;
	numcon = 2;
elseif (fname == 8)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 9)
	aa = -10; bb = 10;
	numcon = 2;
elseif (fname == 10)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 11)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 12)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 13)
	aa = -100; bb = 100;
	numcon = 3;
elseif (fname == 14)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 15)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 16)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 17)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 18)
	aa = -100; bb = 100;
	numcon = 3;
elseif (fname == 19)
	aa = -50; bb = 50;
	numcon = 2;
elseif (fname == 20)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 21)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 22)
	aa = -100; bb = 100;
	numcon = 3;
elseif (fname == 23)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 24)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 25)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 26)
	aa = -100; bb = 100;
	numcon = 2;
elseif (fname == 27)
	aa = -100; bb = 100;
	numcon = 3;
elseif (fname == 28)
	aa = -50; bb = 50;
	numcon = 2;
end
	
end

